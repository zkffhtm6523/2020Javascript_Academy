var s1 = "Wecome to Javascript World~~~ <br>";
var s2 = "Enjoy Javascript Programming!!!";

// 함수 생성
function welcome(target) {
    document.write(target);
}